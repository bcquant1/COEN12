/*
Brandon Quant
COEN 12
Lab 1
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_WORD_LENGTH 30

int main (int argc, char *argv[]){
    char string[MAX_WORD_LENGTH + 1];
    FILE *fp;
    int word_count = 0;

    if (argc < 2) { //checking if all the arguments are present
	printf("The file is missing\n");
	return 0;
    }
    fp = fopen(argv[1], "r"); // opening the text file
    if (fp == NULL){ //checking if the file is empty or not
	printf("File not found\n");
	return 0;
    }    
    while (fscanf(fp, "%s\n", string) == 1){ //running through the text file
	word_count++; 
    }
    fclose(fp); //closing the text file
    printf("%d total words\n", word_count);
    return 0;
}
